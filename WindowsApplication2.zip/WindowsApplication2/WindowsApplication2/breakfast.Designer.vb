﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class breakfast
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.breakfast_label = New System.Windows.Forms.Label()
        Me.close_button = New System.Windows.Forms.Button()
        Me.choice1 = New System.Windows.Forms.RadioButton()
        Me.choice2 = New System.Windows.Forms.RadioButton()
        Me.choice3 = New System.Windows.Forms.RadioButton()
        Me.choice4 = New System.Windows.Forms.RadioButton()
        Me.choice5 = New System.Windows.Forms.RadioButton()
        Me.choice_label = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'breakfast_label
        '
        Me.breakfast_label.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.breakfast_label.Location = New System.Drawing.Point(210, 9)
        Me.breakfast_label.Name = "breakfast_label"
        Me.breakfast_label.Size = New System.Drawing.Size(363, 54)
        Me.breakfast_label.TabIndex = 1
        Me.breakfast_label.Text = "Breakfast Choices"
        '
        'close_button
        '
        Me.close_button.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.close_button.Location = New System.Drawing.Point(641, 370)
        Me.close_button.Name = "close_button"
        Me.close_button.Size = New System.Drawing.Size(111, 52)
        Me.close_button.TabIndex = 2
        Me.close_button.Text = "Back"
        Me.close_button.UseVisualStyleBackColor = True
        '
        'choice1
        '
        Me.choice1.AutoSize = True
        Me.choice1.Location = New System.Drawing.Point(241, 138)
        Me.choice1.Name = "choice1"
        Me.choice1.Size = New System.Drawing.Size(284, 21)
        Me.choice1.TabIndex = 8
        Me.choice1.Text = "Oatmeal with brown sugar - 300 Calories"
        Me.choice1.UseVisualStyleBackColor = True
        '
        'choice2
        '
        Me.choice2.AutoSize = True
        Me.choice2.Location = New System.Drawing.Point(241, 184)
        Me.choice2.Name = "choice2"
        Me.choice2.Size = New System.Drawing.Size(254, 21)
        Me.choice2.TabIndex = 9
        Me.choice2.TabStop = True
        Me.choice2.Text = "Two Scrambled Eggs - 200 Calories"
        Me.choice2.UseVisualStyleBackColor = True
        '
        'choice3
        '
        Me.choice3.AutoSize = True
        Me.choice3.Location = New System.Drawing.Point(241, 232)
        Me.choice3.Name = "choice3"
        Me.choice3.Size = New System.Drawing.Size(278, 21)
        Me.choice3.TabIndex = 10
        Me.choice3.TabStop = True
        Me.choice3.Text = "Bagel with cream cheese - 320 Calories"
        Me.choice3.UseVisualStyleBackColor = True
        '
        'choice4
        '
        Me.choice4.AutoSize = True
        Me.choice4.Location = New System.Drawing.Point(241, 281)
        Me.choice4.Name = "choice4"
        Me.choice4.Size = New System.Drawing.Size(195, 21)
        Me.choice4.TabIndex = 11
        Me.choice4.TabStop = True
        Me.choice4.Text = "Parfait Cup - 230 Calories "
        Me.choice4.UseVisualStyleBackColor = True
        '
        'choice5
        '
        Me.choice5.AutoSize = True
        Me.choice5.Location = New System.Drawing.Point(241, 326)
        Me.choice5.Name = "choice5"
        Me.choice5.Size = New System.Drawing.Size(236, 21)
        Me.choice5.TabIndex = 12
        Me.choice5.TabStop = True
        Me.choice5.Text = "Biscuits and gravy - 415 Calories"
        Me.choice5.UseVisualStyleBackColor = True
        '
        'choice_label
        '
        Me.choice_label.AutoSize = True
        Me.choice_label.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.choice_label.Location = New System.Drawing.Point(236, 96)
        Me.choice_label.Name = "choice_label"
        Me.choice_label.Size = New System.Drawing.Size(198, 25)
        Me.choice_label.TabIndex = 13
        Me.choice_label.Text = "Today's choices are: "
        '
        'breakfast
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(801, 499)
        Me.Controls.Add(Me.choice_label)
        Me.Controls.Add(Me.choice5)
        Me.Controls.Add(Me.choice4)
        Me.Controls.Add(Me.choice3)
        Me.Controls.Add(Me.choice2)
        Me.Controls.Add(Me.choice1)
        Me.Controls.Add(Me.close_button)
        Me.Controls.Add(Me.breakfast_label)
        Me.Name = "breakfast"
        Me.Text = "Breakfast"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents breakfast_label As System.Windows.Forms.Label
    Friend WithEvents close_button As System.Windows.Forms.Button
    Friend WithEvents choice2 As RadioButton
    Friend WithEvents choice3 As RadioButton
    Friend WithEvents choice4 As RadioButton
    Friend WithEvents choice5 As RadioButton
    Friend WithEvents choice_label As Label
    Friend WithEvents choice1 As RadioButton
End Class
