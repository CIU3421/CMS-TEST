﻿Public Class breakfast

    Public Sub breakfastSelect()
        If choice1.Checked = True Then
            opening.breakfastChoice = "Oatmeal with brown sugar"
            opening.breakfastCal = 300
        ElseIf (choice2.Checked = True) Then
            opening.breakfastChoice = "Two scrambled eggs"
            opening.breakfastCal = 200
        ElseIf (choice3.Checked = True) Then
            opening.breakfastChoice = "Bagel with cream cheese"
            opening.breakfastCal = 320
        ElseIf (choice4.Checked = True) Then
            opening.breakfastChoice = "Parfait cup"
            opening.breakfastCal = 230
        ElseIf (choice5.Checked = True) Then
            opening.breakfastChoice = "Biscuits and gravy"
            opening.breakfastCal = 415
        End If
    End Sub
    Public Sub close_button_Click(sender As Object, e As EventArgs) Handles close_button.Click
        Call breakfastSelect()
        Me.Close()
    End Sub


End Class