﻿Public Class dinner
    Public Sub dinnerSelect()
        If choice1.Checked = True Then
            opening.dinnerChoice = "Spaghetti"
            opening.dinnerCal = 600
        ElseIf (choice2.Checked = True) Then
            opening.dinnerChoice = "Fish sandwich"
            opening.dinnerCal = 565
        ElseIf (choice3.Checked = True) Then
            opening.dinnerChoice = "Meatloaf dinner"
            opening.dinnerCal = 650
        ElseIf (choice4.Checked = True) Then
            opening.dinnerChoice = "Turkey dinner"
            opening.dinnerCal = 625
        ElseIf (choice5.Checked = True) Then
            opening.dinnerChoice = "Salad"
            opening.dinnerCal = 350
        End If
    End Sub
    Private Sub close_button_Click(sender As Object, e As EventArgs) Handles close_button.Click
        Call dinnerSelect()
        Me.Close()
    End Sub
End Class