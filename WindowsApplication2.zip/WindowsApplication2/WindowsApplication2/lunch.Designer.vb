﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class lunch
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lunch_label = New System.Windows.Forms.Label()
        Me.close_button = New System.Windows.Forms.Button()
        Me.choice_label = New System.Windows.Forms.Label()
        Me.choice5 = New System.Windows.Forms.RadioButton()
        Me.choice4 = New System.Windows.Forms.RadioButton()
        Me.choice3 = New System.Windows.Forms.RadioButton()
        Me.choice2 = New System.Windows.Forms.RadioButton()
        Me.choice1 = New System.Windows.Forms.RadioButton()
        Me.SuspendLayout()
        '
        'lunch_label
        '
        Me.lunch_label.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lunch_label.Location = New System.Drawing.Point(247, 34)
        Me.lunch_label.Name = "lunch_label"
        Me.lunch_label.Size = New System.Drawing.Size(363, 54)
        Me.lunch_label.TabIndex = 2
        Me.lunch_label.Text = "Lunch Choices"
        '
        'close_button
        '
        Me.close_button.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.close_button.Location = New System.Drawing.Point(651, 408)
        Me.close_button.Name = "close_button"
        Me.close_button.Size = New System.Drawing.Size(111, 52)
        Me.close_button.TabIndex = 3
        Me.close_button.Text = "Back"
        Me.close_button.UseVisualStyleBackColor = True
        '
        'choice_label
        '
        Me.choice_label.AutoSize = True
        Me.choice_label.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.choice_label.Location = New System.Drawing.Point(250, 118)
        Me.choice_label.Name = "choice_label"
        Me.choice_label.Size = New System.Drawing.Size(198, 25)
        Me.choice_label.TabIndex = 19
        Me.choice_label.Text = "Today's choices are: "
        '
        'choice5
        '
        Me.choice5.AutoSize = True
        Me.choice5.Location = New System.Drawing.Point(255, 348)
        Me.choice5.Name = "choice5"
        Me.choice5.Size = New System.Drawing.Size(204, 21)
        Me.choice5.TabIndex = 18
        Me.choice5.TabStop = True
        Me.choice5.Text = "Slice of pizza - 270 Calories"
        Me.choice5.UseVisualStyleBackColor = True
        '
        'choice4
        '
        Me.choice4.AutoSize = True
        Me.choice4.Location = New System.Drawing.Point(255, 303)
        Me.choice4.Name = "choice4"
        Me.choice4.Size = New System.Drawing.Size(197, 21)
        Me.choice4.TabIndex = 17
        Me.choice4.TabStop = True
        Me.choice4.Text = "Cup of soup - 240 Calories"
        Me.choice4.UseVisualStyleBackColor = True
        '
        'choice3
        '
        Me.choice3.AutoSize = True
        Me.choice3.Location = New System.Drawing.Point(255, 254)
        Me.choice3.Name = "choice3"
        Me.choice3.Size = New System.Drawing.Size(192, 21)
        Me.choice3.TabIndex = 16
        Me.choice3.TabStop = True
        Me.choice3.Text = "Hamburger - 400 Calories"
        Me.choice3.UseVisualStyleBackColor = True
        '
        'choice2
        '
        Me.choice2.AutoSize = True
        Me.choice2.Location = New System.Drawing.Point(255, 206)
        Me.choice2.Name = "choice2"
        Me.choice2.Size = New System.Drawing.Size(209, 21)
        Me.choice2.TabIndex = 15
        Me.choice2.TabStop = True
        Me.choice2.Text = "Chicken Wrap - 350 Calories"
        Me.choice2.UseVisualStyleBackColor = True
        '
        'choice1
        '
        Me.choice1.AutoSize = True
        Me.choice1.Location = New System.Drawing.Point(255, 160)
        Me.choice1.Name = "choice1"
        Me.choice1.Size = New System.Drawing.Size(274, 21)
        Me.choice1.TabIndex = 14
        Me.choice1.TabStop = True
        Me.choice1.Text = "Grilled cheese sandwich - 490 Calories"
        Me.choice1.UseVisualStyleBackColor = True
        '
        'lunch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(801, 499)
        Me.Controls.Add(Me.choice_label)
        Me.Controls.Add(Me.choice5)
        Me.Controls.Add(Me.choice4)
        Me.Controls.Add(Me.choice3)
        Me.Controls.Add(Me.choice2)
        Me.Controls.Add(Me.choice1)
        Me.Controls.Add(Me.close_button)
        Me.Controls.Add(Me.lunch_label)
        Me.Name = "lunch"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lunch_label As System.Windows.Forms.Label
    Friend WithEvents close_button As System.Windows.Forms.Button
    Friend WithEvents choice_label As Label
    Friend WithEvents choice5 As RadioButton
    Friend WithEvents choice4 As RadioButton
    Friend WithEvents choice3 As RadioButton
    Friend WithEvents choice2 As RadioButton
    Friend WithEvents choice1 As RadioButton
End Class
