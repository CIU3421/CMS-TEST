﻿Public Class lunch
    Public Sub lunchSelect()
        If choice1.Checked = True Then
            opening.lunchChoice = "Grilled cheese sandwich"
            opening.lunchCal = 490
        ElseIf (choice2.Checked = True) Then
            opening.lunchChoice = "Chicken wrap"
            opening.lunchCal = 350
        ElseIf (choice3.Checked = True) Then
            opening.lunchChoice = "Hamburger"
            opening.lunchCal = 400
        ElseIf (choice4.Checked = True) Then
            opening.lunchChoice = "Cup of soup"
            opening.lunchCal = 240
        ElseIf (choice5.Checked = True) Then
            opening.lunchChoice = "Slice of pizza"
            opening.lunchCal = 270
        End If
    End Sub

    Private Sub close_button_Click(sender As Object, e As EventArgs) Handles close_button.Click
        Call lunchSelect()
        Me.Close()
    End Sub


End Class