﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class opening
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.breakfast_form_button = New System.Windows.Forms.Button()
        Me.Lunch_form_button = New System.Windows.Forms.Button()
        Me.dinner_form_button = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.snack_form_button = New System.Windows.Forms.Button()
        Me.Show_total_button = New System.Windows.Forms.Button()
        Me.exit_button = New System.Windows.Forms.Button()
        Me.Clear_choices_button = New System.Windows.Forms.Button()
        Me.weightTb = New System.Windows.Forms.TextBox()
        Me.heightTb = New System.Windows.Forms.TextBox()
        Me.ageTb = New System.Windows.Forms.TextBox()
        Me.directionsLbl = New System.Windows.Forms.Label()
        Me.weightLbl = New System.Windows.Forms.Label()
        Me.heightLbl = New System.Windows.Forms.Label()
        Me.ageLbl = New System.Windows.Forms.Label()
        Me.calcBtn = New System.Windows.Forms.Button()
        Me.maleRb = New System.Windows.Forms.RadioButton()
        Me.femaleRb = New System.Windows.Forms.RadioButton()
        Me.genderLbl = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'breakfast_form_button
        '
        Me.breakfast_form_button.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.breakfast_form_button.Location = New System.Drawing.Point(118, 121)
        Me.breakfast_form_button.Name = "breakfast_form_button"
        Me.breakfast_form_button.Size = New System.Drawing.Size(277, 59)
        Me.breakfast_form_button.TabIndex = 0
        Me.breakfast_form_button.Text = "Breakfast Choices"
        Me.breakfast_form_button.UseVisualStyleBackColor = True
        '
        'Lunch_form_button
        '
        Me.Lunch_form_button.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lunch_form_button.Location = New System.Drawing.Point(118, 190)
        Me.Lunch_form_button.Name = "Lunch_form_button"
        Me.Lunch_form_button.Size = New System.Drawing.Size(277, 59)
        Me.Lunch_form_button.TabIndex = 1
        Me.Lunch_form_button.Text = "Lunch Choices"
        Me.Lunch_form_button.UseVisualStyleBackColor = True
        '
        'dinner_form_button
        '
        Me.dinner_form_button.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dinner_form_button.Location = New System.Drawing.Point(118, 255)
        Me.dinner_form_button.Name = "dinner_form_button"
        Me.dinner_form_button.Size = New System.Drawing.Size(277, 59)
        Me.dinner_form_button.TabIndex = 2
        Me.dinner_form_button.Text = "Dinner Choices"
        Me.dinner_form_button.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(170, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(512, 76)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Diet/Calorie Calculation"
        '
        'snack_form_button
        '
        Me.snack_form_button.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.snack_form_button.Location = New System.Drawing.Point(118, 320)
        Me.snack_form_button.Name = "snack_form_button"
        Me.snack_form_button.Size = New System.Drawing.Size(277, 59)
        Me.snack_form_button.TabIndex = 4
        Me.snack_form_button.Text = "Snack Choices"
        Me.snack_form_button.UseVisualStyleBackColor = True
        '
        'Show_total_button
        '
        Me.Show_total_button.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Show_total_button.Location = New System.Drawing.Point(103, 396)
        Me.Show_total_button.Name = "Show_total_button"
        Me.Show_total_button.Size = New System.Drawing.Size(177, 83)
        Me.Show_total_button.TabIndex = 5
        Me.Show_total_button.Text = "Total Daily Calories"
        Me.Show_total_button.UseVisualStyleBackColor = True
        '
        'exit_button
        '
        Me.exit_button.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exit_button.Location = New System.Drawing.Point(531, 396)
        Me.exit_button.Name = "exit_button"
        Me.exit_button.Size = New System.Drawing.Size(177, 83)
        Me.exit_button.TabIndex = 6
        Me.exit_button.Text = "EXIT"
        Me.exit_button.UseVisualStyleBackColor = True
        '
        'Clear_choices_button
        '
        Me.Clear_choices_button.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Clear_choices_button.Location = New System.Drawing.Point(310, 396)
        Me.Clear_choices_button.Name = "Clear_choices_button"
        Me.Clear_choices_button.Size = New System.Drawing.Size(177, 83)
        Me.Clear_choices_button.TabIndex = 8
        Me.Clear_choices_button.Text = "Clear Choices"
        Me.Clear_choices_button.UseVisualStyleBackColor = True
        '
        'weightTb
        '
        Me.weightTb.Location = New System.Drawing.Point(586, 146)
        Me.weightTb.Name = "weightTb"
        Me.weightTb.Size = New System.Drawing.Size(122, 22)
        Me.weightTb.TabIndex = 9
        '
        'heightTb
        '
        Me.heightTb.Location = New System.Drawing.Point(586, 174)
        Me.heightTb.Name = "heightTb"
        Me.heightTb.Size = New System.Drawing.Size(122, 22)
        Me.heightTb.TabIndex = 10
        '
        'ageTb
        '
        Me.ageTb.Location = New System.Drawing.Point(586, 203)
        Me.ageTb.Name = "ageTb"
        Me.ageTb.Size = New System.Drawing.Size(122, 22)
        Me.ageTb.TabIndex = 11
        '
        'directionsLbl
        '
        Me.directionsLbl.AutoSize = True
        Me.directionsLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.directionsLbl.Location = New System.Drawing.Point(475, 109)
        Me.directionsLbl.Name = "directionsLbl"
        Me.directionsLbl.Size = New System.Drawing.Size(352, 25)
        Me.directionsLbl.TabIndex = 12
        Me.directionsLbl.Text = "Enter your information to calculate BMR"
        '
        'weightLbl
        '
        Me.weightLbl.AutoSize = True
        Me.weightLbl.Location = New System.Drawing.Point(500, 149)
        Me.weightLbl.Name = "weightLbl"
        Me.weightLbl.Size = New System.Drawing.Size(84, 17)
        Me.weightLbl.TabIndex = 13
        Me.weightLbl.Text = "Weight(lbs):"
        '
        'heightLbl
        '
        Me.heightLbl.AutoSize = True
        Me.heightLbl.Location = New System.Drawing.Point(480, 177)
        Me.heightLbl.Name = "heightLbl"
        Me.heightLbl.Size = New System.Drawing.Size(104, 17)
        Me.heightLbl.TabIndex = 14
        Me.heightLbl.Text = "Height(inches):"
        '
        'ageLbl
        '
        Me.ageLbl.AutoSize = True
        Me.ageLbl.Location = New System.Drawing.Point(547, 205)
        Me.ageLbl.Name = "ageLbl"
        Me.ageLbl.Size = New System.Drawing.Size(37, 17)
        Me.ageLbl.TabIndex = 15
        Me.ageLbl.Text = "Age:"
        '
        'calcBtn
        '
        Me.calcBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.calcBtn.Location = New System.Drawing.Point(586, 268)
        Me.calcBtn.Name = "calcBtn"
        Me.calcBtn.Size = New System.Drawing.Size(140, 72)
        Me.calcBtn.TabIndex = 16
        Me.calcBtn.Text = "Calculate BMR"
        Me.calcBtn.UseVisualStyleBackColor = True
        '
        'maleRb
        '
        Me.maleRb.AutoSize = True
        Me.maleRb.Location = New System.Drawing.Point(586, 231)
        Me.maleRb.Name = "maleRb"
        Me.maleRb.Size = New System.Drawing.Size(59, 21)
        Me.maleRb.TabIndex = 17
        Me.maleRb.TabStop = True
        Me.maleRb.Text = "Male"
        Me.maleRb.UseVisualStyleBackColor = True
        '
        'femaleRb
        '
        Me.femaleRb.AutoSize = True
        Me.femaleRb.Location = New System.Drawing.Point(651, 231)
        Me.femaleRb.Name = "femaleRb"
        Me.femaleRb.Size = New System.Drawing.Size(75, 21)
        Me.femaleRb.TabIndex = 18
        Me.femaleRb.TabStop = True
        Me.femaleRb.Text = "Female"
        Me.femaleRb.UseVisualStyleBackColor = True
        '
        'genderLbl
        '
        Me.genderLbl.AutoSize = True
        Me.genderLbl.Location = New System.Drawing.Point(524, 231)
        Me.genderLbl.Name = "genderLbl"
        Me.genderLbl.Size = New System.Drawing.Size(60, 17)
        Me.genderLbl.TabIndex = 19
        Me.genderLbl.Text = "Gender:"
        '
        'opening
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Fuchsia
        Me.ClientSize = New System.Drawing.Size(839, 526)
        Me.Controls.Add(Me.genderLbl)
        Me.Controls.Add(Me.femaleRb)
        Me.Controls.Add(Me.maleRb)
        Me.Controls.Add(Me.calcBtn)
        Me.Controls.Add(Me.ageLbl)
        Me.Controls.Add(Me.heightLbl)
        Me.Controls.Add(Me.weightLbl)
        Me.Controls.Add(Me.directionsLbl)
        Me.Controls.Add(Me.ageTb)
        Me.Controls.Add(Me.heightTb)
        Me.Controls.Add(Me.weightTb)
        Me.Controls.Add(Me.Clear_choices_button)
        Me.Controls.Add(Me.exit_button)
        Me.Controls.Add(Me.Show_total_button)
        Me.Controls.Add(Me.snack_form_button)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dinner_form_button)
        Me.Controls.Add(Me.Lunch_form_button)
        Me.Controls.Add(Me.breakfast_form_button)
        Me.Name = "opening"
        Me.Text = "diet"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents breakfast_form_button As System.Windows.Forms.Button
    Friend WithEvents Lunch_form_button As System.Windows.Forms.Button
    Friend WithEvents dinner_form_button As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents snack_form_button As System.Windows.Forms.Button
    Friend WithEvents Show_total_button As System.Windows.Forms.Button
    Friend WithEvents exit_button As System.Windows.Forms.Button
    Friend WithEvents Clear_choices_button As Button
    Friend WithEvents weightTb As TextBox
    Friend WithEvents heightTb As TextBox
    Friend WithEvents ageTb As TextBox
    Friend WithEvents directionsLbl As Label
    Friend WithEvents weightLbl As Label
    Friend WithEvents heightLbl As Label
    Friend WithEvents ageLbl As Label
    Friend WithEvents calcBtn As Button
    Friend WithEvents maleRb As RadioButton
    Friend WithEvents femaleRb As RadioButton
    Friend WithEvents genderLbl As Label
End Class
