﻿Public Class opening
    Public breakfastChoice As String
    Public breakfastCal As Integer
    Public lunchChoice As String
    Public lunchCal As Integer
    Public dinnerChoice As String
    Public dinnerCal As Integer
    Public snackChoice As String
    Public snackCal As Integer
    Public totalCal As Integer
    Public weight As Double
    Public height As Double
    Public age As Double
    Public BMR As Double

    Private Sub breakfast_form_button_Click(sender As Object, e As EventArgs) Handles breakfast_form_button.Click
        Dim breakfast_form As New breakfast
        breakfast_form.ShowDialog()
    End Sub

    Private Sub Lunch_form_button_Click(sender As Object, e As EventArgs) Handles Lunch_form_button.Click
        Dim lunch_form As New lunch
        lunch.ShowDialog()
    End Sub
    Private Sub dinner_form_button_Click(sender As Object, e As EventArgs) Handles dinner_form_button.Click
        Dim dinner_form As New dinner
        dinner_form.ShowDialog()
    End Sub

    Private Sub snack_form_button_Click(sender As Object, e As EventArgs) Handles snack_form_button.Click
        Dim snack_form As New snack
        snack.ShowDialog()
    End Sub

    Private Sub exit_button_Click(sender As Object, e As EventArgs) Handles exit_button.Click
        Me.Close()
    End Sub

    Private Sub opening_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        If (MessageBox.Show("Are you sure you want to close the diet program?", "Confirm to exit", MessageBoxButtons.YesNo) = DialogResult.Yes) Then
            e.Cancel = False
        Else
            e.Cancel = True
        End If

    End Sub

    Private Sub opening_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        MessageBox.Show("Goodbye!")
    End Sub

    Private Sub Show_total_button_Click(sender As Object, e As EventArgs) Handles Show_total_button.Click
        totalCal = breakfastCal + lunchCal + dinnerCal + snackCal
        MessageBox.Show("Breakfast Selection: " & breakfastChoice & vbNewLine &
                        "Lunch Selection: " & lunchChoice & vbNewLine &
                        "Dinner Selection: " & dinnerChoice & vbNewLine &
                        "Snack Selection: " & snackChoice & vbNewLine &
                        "Total Calories: " & totalCal)
    End Sub

    Private Sub Clear_choices_button_Click(sender As Object, e As EventArgs) Handles Clear_choices_button.Click
        breakfastChoice = ""
        breakfastCal = 0
        breakfast.choice1.Checked = False
        breakfast.choice2.Checked = False
        breakfast.choice3.Checked = False
        breakfast.choice4.Checked = False
        breakfast.choice5.Checked = False

        lunchChoice = ""
        lunchCal = 0
        lunch.choice1.Checked = False
        lunch.choice2.Checked = False
        lunch.choice3.Checked = False
        lunch.choice4.Checked = False
        lunch.choice5.Checked = False

        dinnerChoice = ""
        dinnerCal = 0
        dinner.choice1.Checked = False
        dinner.choice2.Checked = False
        dinner.choice3.Checked = False
        dinner.choice4.Checked = False
        dinner.choice5.Checked = False

        snackChoice = ""
        snackCal = 0
        snack.choice1.Checked = False
        snack.choice2.Checked = False
        snack.choice3.Checked = False
        snack.choice4.Checked = False
        snack.choice5.Checked = False

    End Sub

    Private Sub calcBtn_Click(sender As Object, e As EventArgs) Handles calcBtn.Click
        weight = CDbl(weightTb.Text)
        height = CDbl(heightTb.Text)
        age = CDbl(ageTb.Text)

        weight = (weight / 2.2)
        height = (height * 2.54)

        If maleRb.Checked = True Then
            BMR = 66.47 + (13.75 * weight) + (5.0 * height) - (6.75 * age)
        ElseIf femaleRb.Checked = True Then
            BMR = 665.09 + (9.56 * weight) + (1.84 * height) - (4.67 * age)
        End If
        MessageBox.Show(CType(BMR, String))
        If BMR < totalCal Then
            MessageBox.Show("Reduce the amount of calories in order to loose weight.")
        Else
            MessageBox.Show("You are on the right path to loose weight.")
        End If
    End Sub


End Class
