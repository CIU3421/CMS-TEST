﻿Public Class snack
    Public Sub snackSelect()
        If choice1.Checked = True Then
            opening.snackChoice = "Peanut butter crackers"
            opening.snackCal = 190
        ElseIf (choice2.Checked = True) Then
            opening.snackChoice = "Apple slices"
            opening.snackCal = 90
        ElseIf (choice3.Checked = True) Then
            opening.snackChoice = "Bag of chips"
            opening.snackCal = 160
        ElseIf (choice4.Checked = True) Then
            opening.snackChoice = "Peanuts"
            opening.snackCal = 170
        ElseIf (choice5.Checked = True) Then
            opening.snackChoice = "Pack of cookies"
            opening.snackCal = 290
        End If
    End Sub

    Private Sub close_button_Click(sender As Object, e As EventArgs) Handles close_button.Click
        Call snackSelect()
        Me.Close()
    End Sub
End Class